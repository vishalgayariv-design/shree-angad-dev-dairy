
// Firebase bootstrap — kept inline so the app also works when opened as a local content:// file.
(function(){
  try {
    const firebaseConfig = {
      apiKey: "AIzaSyBtsZfAuD16G7OeVtxo-1wEJlhLYTNwiLw",
      authDomain: "shree-angad-dev-doodh-dairy.firebaseapp.com",
      projectId: "shree-angad-dev-doodh-dairy",
      storageBucket: "shree-angad-dev-doodh-dairy.firebasestorage.app",
      messagingSenderId: "1070186997385",
      appId: "1:1070186997385:web:fd638ce63b545252a34858",
      measurementId: "G-3WQSF5S6ZM"
    };
    if (!firebase.apps.length) firebase.initializeApp(firebaseConfig);
    window.firebaseDb = firebase.firestore();
    try { window.firebaseDb.settings({experimentalForceLongPolling:true}); } catch (_) {}
    window.firebaseAuth = firebase.auth();
    window.ADMIN_EMAIL = "vishalgayariv@gmail.com";
    window.firebaseInitError = null;
  } catch (e) {
    window.firebaseInitError = e;
    console.error('Firebase initialization failed:', e);
  }
})();

const defaultProducts = [
  {id:1,n:'Normal Milk',h:'साधारण दूध',p:60,s:'500 ml–10 L',e:'🥛',milk:true},
  {id:2,n:'Special / Premium Milk',h:'स्पेशल / प्रीमियम दूध',p:70,s:'500 ml–10 L',e:'🥛',milk:true},
  {id:3,n:'Golden Milk',h:'गोल्डन दूध',p:80,s:'500 ml–10 L',e:'🥛',milk:true},
  {id:4,n:'Curd',h:'दही',p:40,s:'500 ml',e:'🥣'},
  {id:5,n:'Paneer',h:'पनीर',p:90,s:'250 g',e:'🧀'},
  {id:6,n:'Ghee',h:'घी',p:320,s:'500 ml',e:'🫙'},
  {id:7,n:'Lassi',h:'लस्सी',p:45,s:'500 ml',e:'🥤'},
  {id:8,n:'Buttermilk',h:'छाछ',p:25,s:'500 ml',e:'🥛'},
  {id:9,n:'Gulab Jamun',h:'गुलाब जामुन',p:120,s:'250 g',e:'🍬'}
];
async function ensureCustomerAuth(){
  if(window.firebaseInitError) throw window.firebaseInitError;
  if(window.firebaseAuth.currentUser) return window.firebaseAuth.currentUser;
  const result = await window.firebaseAuth.signInAnonymously();
  return result.user;
}
async function loadProductsFromFirebase(){
  const snap = await window.firebaseDb.collection('products').orderBy('id').get();
  if(!snap.empty) return snap.docs.map(d => ({id:d.id, ...d.data(), id:d.data().id || d.id}));
  return defaultProducts.slice();
}
async function seedProductsIfNeeded(){
  const snap = await window.firebaseDb.collection('products').limit(1).get();
  if(!snap.empty) return;
  const batch = window.firebaseDb.batch();
  defaultProducts.forEach(p => batch.set(window.firebaseDb.collection('products').doc(String(p.id)), p));
  await batch.commit();
}
function isAdminUser(user){
  return !!user && !!user.email && user.email.toLowerCase() === window.ADMIN_EMAIL.toLowerCase();
}
