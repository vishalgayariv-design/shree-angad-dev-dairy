Shree Angad Dev Doodh Dairy - Firebase v15

Fix: Firestore writes use long-polling for better reliability on mobile/local content:// pages and order save now has a 15-second timeout with a clear error.

For production, deploy the public/ folder using Firebase Hosting over HTTPS.
