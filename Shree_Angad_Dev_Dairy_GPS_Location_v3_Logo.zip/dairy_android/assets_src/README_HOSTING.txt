SHREE ANGAD DEV DOODH DAIRY - FIREBASE HOSTING READY

Project: shree-angad-dev-doodh-dairy

This package is ready for Firebase Hosting.

On a computer with Node.js and Firebase CLI installed, open this folder and run:
  firebase login
  firebase use shree-angad-dev-doodh-dairy
  firebase deploy --only hosting

The site will then be served over HTTPS instead of content:// local-file mode.
