Shree Angad Dev Doodh Dairy — Firebase v8 fix

Firebase config updated to the latest Web App.
Firebase bootstrap is now inline in index.html and admin.html, so the app no longer depends on loading firebase-init.js from a content:// page.

For production, host the app on HTTPS (Firebase Hosting or another web host). Keep Firestore rules secure; do not use allow create: if true in production.


v11 FIX: Customer products/categories now render immediately before Firebase loads, so local content:// opening no longer leaves a blank catalogue. Mobile category buttons are visible and clickable, and bottom navigation no longer covers product cards.
