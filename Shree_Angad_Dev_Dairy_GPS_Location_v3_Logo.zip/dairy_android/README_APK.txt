Shree Angad Dev Doodh Dairy — Android App

Version 1.1
- Uses live Firebase Hosting URL.
- Requests Android precise location permission when customer taps Use Current Location.
- Saves GPS latitude/longitude/accuracy with each order.
- Admin order card shows Customer Location button to open Google Maps.
- compileSdk/targetSdk 36 for current Google Play target requirement.

Build: Gradle 8.9 + Java 17, task assembleDebug for testing or bundleRelease for Play Store.
