Shree Angad Dev Doodh Dairy - Android App Project

This is an Android Studio project prepared to load the Firebase Hosting version of the dairy app.

IMPORTANT:
The app intentionally loads the HTTPS Firebase Hosting URL:
https://shree-angad-dev-doodh-dairy.web.app/

Firebase Hosting must be deployed first. Do not expect the APK to work correctly while the site is only opened as content:// local files.

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the generated APK on the phone.

The web app files are also included under app/src/main/assets for reference, but the MainActivity uses the HTTPS hosted site so Firebase Authentication/Firestore use a real web origin.
